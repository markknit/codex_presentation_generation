CELL STRUCTURE · LESSONS 1, 2, 4, 6 · VERSION 2
REVIEW DRAFTS — NOT APPROVED FOR CLASSROOM RELEASE

Start with CellStructure_v2_QuickReview.pdf (17 selected slides), then review each separate PPTX and full PDF. PPTX contains editable text/science diagrams and complete teacher speaker notes. Slides 2–3 are hidden; PDFs deliberately include them.

L1: 21 slides / 40 min. L2: 25 / 80. L4: 37 / 80. L6: 27 / 80.

The DesignGuide explains the repeatable method. Exact illustration prompts are in image_provenance.json. New L4 applies the same design components to content absent from the three supplied references. Source excerpts under reusable_design require the full repository (source data, theme, notes, assets, helper module and pinned requirements); the ZIP is a review package, not a standalone build environment.

Print L4 BlankTasks before Predict; labelled reference sheets only after Predict. L2 reference sheets contain the reading/table/cards. L6 sheet is blank: actual observations remain the pupil evidence.

Open checks: native PowerPoint and Presenter View; exact Calibri rendering; ARES/offline resources; teacher/source-owner decisions; L6 stain/PPE/equipment/calibration. L4 uses the source-permitted diagram-only route, not fabricated EM images. See build logs and qa evidence in the ZIP.
