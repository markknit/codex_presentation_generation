# Cell Structure pilot lessons 1, 2, 3, 6 — review drafts

84 total slides. Each separate deck has hidden teacher slides 2–3; review PDFs include all pages. Full speaker notes and per-lesson build logs are included.

The user authorised adding these lessons to the pilot. They are not approved for classroom use or release. Native PowerPoint/Presenter View, Calibri, ARES and teacher/source-owner checks remain open.

If Lesson 6 is included, its iodine/PPE/fallback, actual microscope visibility, field calibration and local risk-assessment decisions require teacher sign-off. L4–5 remain prerequisites, not newly generated lessons. The L6 observation sheet is blank; reference drawings and example calculations must not replace pupil data.

CUDA processes all raster previews and pixel signals. PPTX assembly, conversion and file/layout work use CPU operations. These checks are not scientific or safety approval.
